import 'package:flutter/material.dart';

class AppConstants {
  static const String transactionsJsonPath = 'assets/transactions.json';
  static const List<String> tabs = ['All', 'This Month', 'Last Month'];
  static const Color primaryColor = Color(0xFF4A90E2);
  static const Color backgroundColor = Color(0xFFF5F7FA);
  static const Color cardColor = Color(0xFFFFFFFF);
}