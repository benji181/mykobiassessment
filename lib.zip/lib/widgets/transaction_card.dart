import 'package:flutter/material.dart';
import '../models/transaction.dart';
import '../constants/app_constants.dart';

class TransactionCard extends StatelessWidget {
  final Transaction transaction;
  final VoidCallback onTap;

  const TransactionCard({Key? key, required this.transaction, required this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FadeInAnimation(
      child: Card(
        color: AppConstants.cardColor,
        elevation: 2,
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        child: ListTile(
          // Icon: Netflix logo (replaced with local image)
          leading: CircleAvatar(
            backgroundColor: Colors.black,
            child: Image.asset(
              'assets/N.png', // Replace with your image path
              fit: BoxFit.cover,
              width: 40,
              height: 40,

            ),
          ),
          // Label: Merchant name
          title: Text(
            transaction.merchant,
            style: TextStyle(color: AppConstants.primaryColor, fontSize: 16, fontWeight: FontWeight.w500),
          ),
          // Subtitle: Formatted date
          subtitle: Text(
            transaction.formattedDate,
            style: const TextStyle(fontSize: 12, color: Colors.black54),
          ),
          // Amount: Transaction amount in orange
          trailing: Text(
            '\$${transaction.amount.abs().toStringAsFixed(2)}',
            style: TextStyle(
              color: transaction.amount < 0 ? Colors.orange : Colors.green,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          onTap: onTap,
        ),
      ),
    );
  }
}

class FadeInAnimation extends StatefulWidget {
  final Widget child;

  const FadeInAnimation({Key? key, required this.child}) : super(key: key);

  @override
  _FadeInAnimationState createState() => _FadeInAnimationState();
}

class _FadeInAnimationState extends State<FadeInAnimation> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _animation = Tween<double>(begin: 0, end: 1).animate(_controller);
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _animation,
      child: widget.child,
    );
  }
}